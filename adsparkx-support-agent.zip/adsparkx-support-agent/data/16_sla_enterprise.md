# Enterprise SLA and Account Management

## Service Level Agreement
Enterprise contracts include a 99.95% monthly uptime SLA. Service credits for breaches are calculated as a percentage of monthly fees and applied automatically as detailed in the order form, ranging from 5% credit (uptime 99.0%-99.94%) up to 30% credit (uptime below 99.0%).

## Dedicated Account Manager
Enterprise customers are assigned a named account manager for quarterly business reviews, onboarding support, and escalation of critical issues outside the standard support queue.

## Custom Contract Terms
Enterprise order forms may include custom terms for data residency, refund policy, payment terms (e.g., net-30 invoicing), and dedicated infrastructure. Any request to modify a signed Enterprise contract must be escalated to the account manager and is outside the scope of standard support.

## Priority Support Response Times
- Business plan: First response within 8 business hours.
- Enterprise plan: First response within 1 hour for Severity 1 issues, 4 hours for Severity 2, 1 business day for Severity 3.
