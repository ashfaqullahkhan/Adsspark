# Security and Compliance

## Data Encryption
All data in transit is encrypted using TLS 1.2 or higher. Data at rest is encrypted using AES-256. Encryption keys are managed through a cloud KMS with quarterly rotation.

## Compliance Certifications
CloudDesk is SOC 2 Type II certified and GDPR compliant. Enterprise customers can request a copy of the latest SOC 2 report and a signed Data Processing Agreement (DPA) from their account manager.

## Single Sign-On (SSO)
SSO via SAML 2.0 is available on Business and Enterprise plans, supporting providers including Okta, Azure AD, and Google Workspace. SSO setup requires Admin access and an exchange of metadata XML between CloudDesk and your identity provider.

## Reporting a Security Vulnerability
Security researchers can report vulnerabilities to security@clouddesk.com. Do not disclose vulnerabilities publicly before our security team has had the opportunity to investigate and remediate (responsible disclosure window: 90 days).

## Data Residency
Enterprise customers can request data residency in a specific region (US, EU, or APAC) at workspace creation time. Changing data residency after creation requires a full data migration and must be arranged with your account manager.
