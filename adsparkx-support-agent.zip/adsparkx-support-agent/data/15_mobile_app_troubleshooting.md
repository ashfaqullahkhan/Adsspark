# Mobile App Troubleshooting

## App Crashes on Launch
1. Confirm you are on the latest app version (App Store / Google Play).
2. Restart your device.
3. If the crash persists, reinstall the app — this clears any corrupted local cache without affecting your cloud data.
4. If crashes continue after reinstalling, contact support with your device model, OS version, and app version so we can investigate crash logs.

## Sync Issues Between Mobile and Web
Mobile app changes typically sync within a few seconds when online. If changes made on mobile are not appearing on web (or vice versa):
- Confirm both devices have an active internet connection.
- Pull down to refresh on the mobile app's main task list.
- Log out and back in on the device with the sync issue (this forces a full re-sync).

## Push Notifications Not Working on Mobile
Confirm notifications are enabled both in the CloudDesk app settings and in your device's system-level notification settings for the CloudDesk app. iOS users should also confirm "Background App Refresh" is enabled for CloudDesk.

## Offline Mode
The mobile app supports limited offline mode: you can view recently loaded tasks and add comments while offline, which sync automatically once connectivity is restored. Creating new projects requires an active connection.
