# Notification Settings

## Notification Channels
CloudDesk can notify you via in-app notifications, email, mobile push, and Slack (if connected). Configure preferences per channel from Settings > Notifications.

## Notification Types
- Task assigned to you
- Task due date approaching (24 hours and 1 hour before, by default)
- Comment mentions (@you)
- Project status changes
- Daily/weekly digest summaries

## Not Receiving Email Notifications
1. Check Settings > Notifications > Email is toggled on for the relevant notification type.
2. Check your spam folder for emails from notifications@clouddesk.com.
3. Corporate email filters sometimes block bulk-looking emails; ask IT to allowlist the domain.
4. Notification emails are batched every 5 minutes during high-activity periods rather than sent instantly, by design, to reduce inbox noise.

## Muting Projects or Threads
You can mute a specific project or comment thread from the "..." menu to stop notifications without changing your global settings.
