# API Authentication Guide

## Generating an API Key
Go to Settings > Developer > API Keys and click "Generate New Key." Keys are scoped to a workspace and inherit the permissions of the user who created them. Store your key securely — it is shown only once.

## Authenticating Requests
Include your API key in the Authorization header of every request:

`Authorization: Bearer <your_api_key>`

All API requests must use HTTPS. Requests over plain HTTP are rejected with a 400 error.

## Common Authentication Errors
- **401 Unauthorized — "invalid_api_key"**: The key is malformed, revoked, or expired. Generate a new key from Settings > Developer.
- **401 Unauthorized — "expired_token"**: OAuth access tokens expire after 1 hour. Use the refresh token endpoint (POST /v1/oauth/token with grant_type=refresh_token) to obtain a new access token without requiring the user to log in again.
- **403 Forbidden — "insufficient_scope"**: The API key does not have permission for the requested resource. Check that the key's scopes (read, write, admin) match the operation, and that the underlying user role has access to that project.
- **429 Too Many Requests**: You have exceeded the rate limit (see Rate Limiting article). Implement exponential backoff.

## OAuth 2.0 for Third-Party Apps
CloudDesk supports the OAuth 2.0 Authorization Code flow for third-party integrations. Register your app at developers.clouddesk.com to receive a client_id and client_secret. Redirect URIs must be HTTPS in production environments.

## Rotating and Revoking Keys
Revoke a compromised key immediately from Settings > Developer > API Keys > Revoke. Revoked keys return 401 errors immediately and cannot be reactivated; generate a new key instead.
