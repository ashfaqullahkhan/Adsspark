# Refund Policy

CloudDesk offers a 14-day money-back guarantee for first-time Pro, Business, and Enterprise subscribers. To be eligible:
- The request must be made within 14 calendar days of the initial charge.
- The workspace must not have previously received a refund.
- Annual and monthly plans are both eligible.

## Requesting a Refund
Refund requests must go through human support — this is a billing-sensitive action that cannot be completed by the AI assistant or self-service tools. When you contact us, please provide your workspace name and the invoice ID you wish to be refunded.

## Partial Refunds and Prorated Cancellations
CloudDesk does not provide partial refunds for unused time outside the 14-day window, except where required by local consumer protection law. Enterprise contracts may include custom refund terms as negotiated in the order form.

## Processing Time
Approved refunds are issued to the original payment method and typically appear within 5-10 business days, depending on your bank or card issuer.
