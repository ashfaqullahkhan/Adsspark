# Getting Started with CloudDesk

CloudDesk is a cloud-based project and task management platform for teams.

## Creating Your Account
1. Go to the CloudDesk signup page and enter your work email.
2. Verify your email using the link sent to your inbox (valid for 24 hours).
3. Set a password that is at least 10 characters long and includes a number and a symbol.
4. Choose a workspace name. This becomes part of your CloudDesk URL (e.g., yourcompany.clouddesk.com).

## First Login
After verifying your email, log in at app.clouddesk.com. New users are guided through a 4-step onboarding wizard: invite teammates, create your first project, choose a board layout (Kanban, List, or Timeline), and connect an integration.

## Inviting Team Members
Workspace Admins can invite members from Settings > Members > Invite. Invited users receive an email invitation valid for 7 days. Free plan workspaces are limited to 10 members; Pro and Enterprise plans support unlimited members.

## Supported Browsers and Devices
CloudDesk web app supports the latest two versions of Chrome, Firefox, Edge, and Safari. Native apps are available for iOS 15+, Android 10+, Windows 10/11, and macOS 12+.
