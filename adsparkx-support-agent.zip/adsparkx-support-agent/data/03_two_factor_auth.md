# Two-Factor Authentication (2FA)

## Enabling 2FA
Go to Settings > Security > Two-Factor Authentication and click "Enable." CloudDesk supports authenticator apps (TOTP, e.g., Google Authenticator, Authy) and SMS-based codes. Scan the QR code with your authenticator app and enter the 6-digit code to confirm setup. You will be shown 10 backup codes — store these somewhere safe, as each can be used once if you lose access to your authenticator device.

## Losing Access to Your 2FA Device
If you lose your authenticator device and have no backup codes:
1. This cannot be resolved through self-service for security reasons.
2. The account must be escalated to a human support agent for identity verification (government ID match against account, or verification via workspace Admin).
3. Average resolution time for 2FA recovery is 1-2 business days due to the manual identity verification step.

## Disabling 2FA
Workspace Admins can disable 2FA for a user from Settings > Members > [User] > Security in emergency situations, but this requires Admin-level access and is logged in the audit trail.

## SMS Codes Not Arriving
SMS delivery can be delayed in certain countries due to carrier filtering. We recommend switching to an authenticator app for reliability. If SMS codes consistently fail, contact support with your country and carrier so we can investigate delivery issues.
