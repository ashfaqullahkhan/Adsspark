# Exporting Your Data

## Exporting a Project
Open the project, click the "..." menu, and select "Export." Choose CSV, JSON, or PDF format. CSV and JSON exports include all tasks, comments, custom fields, and timestamps. PDF export is a formatted summary suitable for printing or sharing.

## Exporting an Entire Workspace
Workspace Admins can request a full workspace export from Settings > Data > Export Workspace. This includes all projects, files, comments, and user activity logs. Large workspaces (over 5,000 tasks) may take up to 24 hours to generate; you will receive an email with a secure download link valid for 7 days.

## API-Based Export
Developers can use the CloudDesk REST API (GET /v1/projects/{id}/export) to programmatically retrieve data in JSON format. See the API Authentication Guide for setting up API keys.

## Data Retention After Cancellation
If a workspace is canceled, data is retained for 30 days in case of reactivation, after which it is permanently deleted. We recommend exporting your data before cancellation.
