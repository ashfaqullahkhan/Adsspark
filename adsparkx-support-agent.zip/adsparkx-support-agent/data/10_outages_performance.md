# Performance, Downtime, and Status Updates

## Checking System Status
Real-time uptime and incident status is published at status.clouddesk.com, including historical uptime per region (US, EU, APAC).

## Our Uptime Commitment
- Pro and Business plans: 99.9% uptime target (best-effort, not contractual).
- Enterprise plans: 99.95% uptime SLA with service credits for downtime breaches, as defined in the signed order form.

## What to Do During an Incident
If CloudDesk is slow or unreachable, first check status.clouddesk.com for an active incident. If no incident is listed but you are experiencing issues, this may be local to your account or network — contact support with your workspace name, approximate time the issue started, and a screenshot or HAR file if possible.

## Common Causes of Slowness
- Large projects (10,000+ tasks) in List view can load slowly in older browser versions; switching to Board view often improves performance.
- Browser extensions (especially ad blockers) have been known to interfere with real-time sync; try disabling extensions to test.
- VPNs with high latency routes can slow down real-time collaboration features.

## Reporting a Severity-1 Outage
Business and Enterprise customers experiencing a full workspace outage should mark the support request as Severity 1, which triggers immediate escalation to the on-call engineering team rather than the standard support queue.
