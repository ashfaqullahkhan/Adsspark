# Billing and Subscription Plans

## Available Plans
- **Free**: Up to 10 members, 3 active projects, 1 GB storage.
- **Pro**: $9/user/month (billed annually) or $12/user/month (billed monthly). Unlimited projects, 100 GB storage, integrations, priority support.
- **Business**: $19/user/month (annual). Adds advanced permissions, SSO, audit logs, custom fields.
- **Enterprise**: Custom pricing. Adds dedicated account manager, custom SLA, on-premise data residency options.

## Changing Plans
Workspace Admins can upgrade or downgrade from Settings > Billing > Plan. Upgrades take effect immediately and are prorated for the current billing cycle. Downgrades take effect at the end of the current billing cycle.

## Invoices and Payment Methods
Invoices are generated automatically and sent to the billing email on file. CloudDesk accepts Visa, Mastercard, American Express, and ACH bank transfer (Business and Enterprise plans only). Failed payments are retried 3 times over 7 days before the workspace is downgraded to the Free plan.

## Billing-Sensitive Issues
Any request involving disputed charges, refunds, double billing, or changes to payment terms must be escalated to a human billing specialist. Support agents cannot directly modify financial records.
