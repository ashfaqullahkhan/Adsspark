# API Rate Limiting

## Limits by Plan
- Free: 60 requests/minute, 1,000 requests/day
- Pro: 300 requests/minute, 50,000 requests/day
- Business: 1,000 requests/minute, 250,000 requests/day
- Enterprise: Custom limits negotiated per contract

## Rate Limit Headers
Every API response includes:
- `X-RateLimit-Limit`: total requests allowed in the current window
- `X-RateLimit-Remaining`: requests remaining
- `X-RateLimit-Reset`: Unix timestamp when the limit resets

## Handling 429 Responses
When you receive a 429 status code, the response body includes a `retry_after` field in seconds. We strongly recommend implementing exponential backoff with jitter rather than retrying immediately, as repeated immediate retries can extend your throttling window.

## Requesting a Higher Limit
Business and Enterprise customers with sustained high-volume needs can request a custom rate limit increase by contacting support with their use case and expected request volume.
