# Team Members, Roles, and Permissions

## Roles
- **Owner**: Full control, including billing and workspace deletion. Only one Owner per workspace (can be transferred).
- **Admin**: Manage members, billing (view only unless also Owner), integrations, and security settings.
- **Member**: Create and edit projects/tasks they have access to.
- **Guest**: Limited, read-or-comment-only access to specific projects, typically used for external collaborators (Business and Enterprise plans only).

## Changing a Member's Role
Admins can change roles from Settings > Members > [select user] > Role. Role changes take effect immediately and are recorded in the audit log (Business and Enterprise plans).

## Project-Level Permissions
Within a workspace role, individual projects can be set to Private (invite-only) or Workspace-visible. Private project access is managed by the project creator or an Admin.

## Removing a Member
Removing a member unassigns their tasks (tasks remain in the project but become unassigned) and revokes their access immediately. Removed members' historical comments remain visible for audit purposes.
