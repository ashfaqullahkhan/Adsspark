# Account and Workspace Deletion

## Deleting Your Personal Account
Go to Settings > Account > Delete Account. You will be asked to confirm via email. Personal account deletion removes your profile and personal settings but does not delete workspaces you do not own.

## Deleting a Workspace
Only the workspace Owner can delete an entire workspace, from Settings > Workspace > Delete Workspace. This is irreversible after the 30-day grace period (see Data Export article) and requires typing the workspace name to confirm.

## This Action Requires Escalation When:
- The requester is not the workspace Owner but claims authorization (e.g., Owner left the company). These requests require human verification of authority before any deletion or ownership transfer is performed.
- There is an active paid subscription; deletion does not automatically cancel billing, and a human agent must confirm the subscription is also canceled to avoid further charges.

## Transferring Workspace Ownership
Current Owners can transfer ownership to another Admin from Settings > Workspace > Transfer Ownership. If the current Owner is unreachable (e.g., former employee), ownership transfer requires identity verification by human support and proof of organizational authority (such as a company email domain match).
