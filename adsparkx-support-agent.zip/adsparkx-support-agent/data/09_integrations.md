# Integrations: Slack, Jira, and Google Calendar

## Slack Integration
Connect CloudDesk to Slack from Settings > Integrations > Slack > Connect. Once connected, you can:
- Receive task notifications in a chosen Slack channel
- Create CloudDesk tasks directly from Slack using `/clouddesk create`
- Get daily digest summaries posted to a channel of your choice

If notifications stop arriving, check that the Slack app has not been removed from the workspace by a Slack admin, and reconnect from Settings > Integrations.

## Jira Integration
CloudDesk's Jira integration performs two-way sync of issue status between a CloudDesk project and a Jira project. Initial sync can take up to 30 minutes for projects with more than 1,000 issues. Field mapping (status, assignee, priority) is configured during setup and can be edited later from Settings > Integrations > Jira > Field Mapping.

## Google Calendar Integration
Tasks with due dates can sync to Google Calendar as events. Sync is one-way (CloudDesk to Calendar) on the Free and Pro plans; two-way sync (editing the due date in Calendar updates CloudDesk) is available on Business and Enterprise plans.

## Troubleshooting Integration Failures
If an integration shows "Connection Error," the most common cause is an expired OAuth token on the third-party side. Disconnect and reconnect the integration from Settings > Integrations to refresh authorization.
