# Password Reset Guide

If you are unable to log in to CloudDesk, follow these steps to reset your password.

## Standard Reset
1. On the login page, click "Forgot password."
2. Enter the email address associated with your CloudDesk account.
3. Check your inbox for a password reset email (subject: "Reset your CloudDesk password"). The link expires after 30 minutes.
4. Click the link and set a new password (minimum 10 characters, must include a number and symbol).
5. You will be automatically logged in after a successful reset.

## Troubleshooting "I Never Received the Email"
- Check your spam or promotions folder.
- Confirm you used the correct email address (the one your workspace Admin invited you with).
- Wait at least 5 minutes; email delivery can be delayed during peak hours.
- Add no-reply@clouddesk.com to your contacts/allow list.
- If using a corporate email, ask your IT team if clouddesk.com is blocked by a mail filter.
- If still not received after 15 minutes, request a new reset link rather than reusing an old one (old links are invalidated once a new one is issued).

## Account Locked After Failed Attempts
After 5 consecutive failed login attempts, CloudDesk locks the account for 15 minutes as a security measure. If you believe your account is locked due to unauthorized access attempts, contact support immediately and we will investigate login logs and IP origin.

## Resetting Password When 2FA Is Enabled
If two-factor authentication (2FA) is enabled, you must still complete the 2FA challenge after entering your new password. If you have lost access to your 2FA device, see the "Two-Factor Authentication Recovery" article — this requires identity verification by a human support agent and cannot be self-served.
