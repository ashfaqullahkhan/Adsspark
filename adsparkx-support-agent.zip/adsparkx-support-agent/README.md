# CloudDesk Support Agent — Persona-Adaptive Customer Support Agent

An AI support agent that detects a customer's persona, retrieves grounded
answers from a knowledge base (RAG), adapts tone/format per persona, and
escalates to a human agent with a structured handoff summary when needed.

Built for the Adsparkx AI Assignment (Persona-Aware Customer Support Agent
using LLMs, RAG, and Human Escalation).

---

## 1. Project Overview

The agent answers customer support questions for a fictional SaaS product,
**CloudDesk** (a project/task management tool). It:

- Classifies every incoming message into one of three personas — **Technical
  Expert**, **Frustrated User**, **Business Executive** (plus a **General
  User** fallback) — using a hybrid rule-based classifier, optionally
  confirmed by an LLM.
- Retrieves the most relevant chunks from a 17-document knowledge base using
  a Retrieval-Augmented Generation pipeline.
- Generates a response that is **grounded only in retrieved content** and
  styled to match the detected persona's tone and level of technical detail.
- Evaluates five configurable escalation triggers and, when one fires,
  produces a structured **human handoff summary** (persona, issue,
  documents used, attempted steps, recommendation, full conversation
  history).
- Runs via an interactive **CLI chatbot** (required) and a **Streamlit
  chat UI** (bonus).

### Zero-config mode

The whole pipeline runs **end-to-end with no API keys** using a local
TF-IDF retrieval backend and a deterministic, extractive (non-hallucinating)
response generator. If you add `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, or run
Ollama locally, the agent automatically switches to real LLM generation (and,
for OpenAI, real embedding-based retrieval) — no code changes needed. This
was a deliberate design choice so the grader can run the project immediately
without provisioning any credentials, while the architecture remains fully
"real-LLM ready."

---

## 2. Tech Stack

| Component            | Choice                                   | Version (tested) |
|-----------------------|-------------------------------------------|-------------------|
| Language              | Python                                    | 3.11+             |
| Persona detection     | Custom rule-based classifier (+ optional LLM confirmation) | — |
| LLM (optional)        | Anthropic Claude / OpenAI / Ollama (pluggable) | claude-sonnet-4-6 / gpt-4o-mini / llama3 |
| Retrieval / "vector DB" | scikit-learn `TfidfVectorizer` + cosine similarity (default); OpenAI embeddings backend (optional) | scikit-learn 1.3+ |
| Orchestration         | Plain Python state machine (`SupportSession`) — maps 1:1 to a LangGraph graph, see §8 | — |
| PDF parsing           | `pypdf`                                   | 4.0+              |
| DOCX parsing          | `python-docx`                             | 1.1+              |
| UI                    | CLI (required) + Streamlit (bonus)        | streamlit 1.32+   |
| HTTP                  | `requests`                                | 2.31+             |

No LangChain/LlamaIndex/ChromaDB/FAISS dependency is required to run the
project, since the offline TF-IDF backend covers the "vector database"
requirement without needing native binaries or downloaded model weights.
The code is structured so any of those can be dropped in (`vector_store.py`
already exposes the `add()/query()` interface a real vector DB would use).

---

## 3. Architecture

```
                 ┌────────────────────┐
   User Query →  │  Persona Detection │  (rule-based scorer; optional LLM confirm)
                 └─────────┬──────────┘
                           │ persona, confidence
                           ▼
                 ┌────────────────────┐
                 │  KB Retrieval (RAG)│  TF-IDF / embeddings → top-k chunks
                 └─────────┬──────────┘
                           │ retrieved chunks + relevance scores
                           ▼
                 ┌────────────────────┐
                 │ Response Generation│  persona-styled prompt → LLM
                 │                    │  (or template-based extractive fallback)
                 └─────────┬──────────┘
                           │ grounded response
                           ▼
                 ┌────────────────────┐
                 │  Escalation Check  │  5 configurable triggers
                 └─────────┬──────────┘
                  no │             │ yes
                     ▼             ▼
              Return reply   ┌────────────────────┐
                              │  Human Handoff      │  structured JSON summary
                              │  Summary             │
                              └────────────────────┘
```

This is implemented in `src/agent.py` as `SupportSession.handle_message()`,
which runs the five stages above for every turn and maintains session state
(conversation history, repeated-frustration counter) across turns.

---

## 4. Persona Detection Strategy

**Classification method:** hybrid rule-based scoring (`src/persona_detector.py`).
Each persona gets a weighted score from three signal types:

1. **Lexical signals** — curated keyword/phrase lists (e.g., "API",
   "stack trace", "401" for Technical Expert; "tried everything",
   "frustrated", "ridiculous" for Frustrated User; "business impact",
   "SLA", "stakeholders" for Business Executive).
2. **Structural signals** — exclamation density, ALL-CAPS word count,
   presence of HTTP-status-code-like patterns or stack traces, message
   terseness.
3. **Sentiment signal** — a small negative-word lexicon that nudges
   "Frustrated User" up independent of vocabulary overlap.

The persona with the highest weighted score wins; if no persona clears a
minimum confidence floor (0.18), the message is classified as **General
User** rather than being forced into one of the three.

**Why rule-based instead of always calling an LLM?** Persona detection runs
on every single turn. A deterministic classifier is instant, free, fully
explainable to a support team auditing why a message was routed a certain
way, and doesn't depend on an API key being present — which matters because
this project must run in zero-config mode. `detect_persona_llm()` is also
provided and will use a real LLM call to confirm/override borderline cases
when a key is configured (`session = SupportSession(..., use_llm_for_persona=True)`).

**Prompt design (LLM-confirmation path):** a single constrained instruction
("classify into exactly one of these four labels, reply with only the
label") keeps the LLM call cheap and removes ambiguity in parsing the
response.

---

## 5. RAG Pipeline Design

**Document loading** (`src/knowledge_base.py`): supports `.md`, `.txt`,
`.pdf`, and `.docx`. 17 documents ship in `/data` (16 Markdown + 1 PDF),
covering account/password management, 2FA, billing, refunds, data export,
API authentication & rate limiting, integrations, outages/performance,
security & compliance, account deletion, notifications, team permissions,
mobile troubleshooting, Enterprise SLAs, and a security-incident policy.

**Chunking strategy:**
- Markdown/TXT/DOCX are first split by `##` heading, so each chunk stays
  topically coherent and metadata can record a meaningful `section` name
  (not just "chunk 7").
- PDFs are split per page first (so `section` = "Page N"), then the same
  size-based splitter is applied within a page/section.
- Any section/page exceeding 900 characters is further split with a
  sliding window (120-character overlap) so individual chunks stay small
  enough for precise retrieval while preserving context across the cut.
- Every chunk carries `source` (filename) and `section` (heading or page),
  which is what populates `documents_used` in the escalation handoff.

**Embedding model / vector database:**
- Default (zero-config): `TfidfVectorizer` (scikit-learn) + cosine
  similarity — a fully local, dependency-light substitute for a vector DB
  that needs no downloaded model weights or internet access.
- Optional: when `OPENAI_API_KEY` is set, `vector_store.build_vector_store()`
  automatically switches to `EmbeddingVectorStore`, which calls OpenAI's
  `text-embedding-3-small` endpoint and stores embeddings as an in-memory
  numpy matrix, again using cosine similarity for retrieval. The interface
  (`add()`, `query()`) is identical either way, so the rest of the pipeline
  doesn't know or care which backend is active — this is the same
  abstraction a real ChromaDB/FAISS/Pinecone integration would sit behind.

**Retrieval strategy:** top-`k` (default 4) chunks by cosine similarity are
retrieved per user message. The top score is also used directly as the
*retrieval confidence* signal for escalation (see §6).

---

## 6. Escalation Logic (`src/escalation.py`)

Escalation triggers (all individually toggle-able / tunable via
`EscalationConfig`):

| Trigger | Condition |
|---|---|
| `no_relevant_docs_found` | Retrieval returned zero chunks above similarity 0 |
| `retrieval_confidence_low` | Top retrieved chunk's similarity score is below `confidence_threshold` (default **0.12**) |
| `sensitive_topic` | Message matches a billing / legal / account-security keyword list (refunds, chargebacks, account deletion, data breach, GDPR, etc.) — these **always** escalate regardless of retrieval quality, since the assignment requires billing/legal/account-sensitive issues to go to a human |
| `repeated_dissatisfaction` | The user has been classified as **Frustrated User** in `frustration_repeat_threshold` (default **2**) or more turns in the same session |
| `explicit_human_request` | The message asks for a human/agent/manager directly |

When any trigger fires, `src/handoff.py` builds a structured JSON summary:

```json
{
  "persona": "Frustrated User",
  "issue": "Unable to reset password",
  "documents_used": ["password_reset_guide.md"],
  "attempted_steps": ["...agent's prior reply text..."],
  "recommendation": "Knowledge base did not have a confident answer; investigate directly...",
  "escalation_reasons": ["retrieval_confidence_low (0.07 < 0.12)"],
  "conversation_history": [ ... ],
  "timestamp": "2026-06-20T07:32:28Z"
}
```

`documents_used`, `attempted_steps`, and `recommendation` match the schema
given in the assignment; `escalation_reasons`, `conversation_history`, and
`timestamp` are additive fields for a richer human handoff.

---

## 7. Setup Instructions

```bash
# 1. Clone the repo
git clone <your-repo-url>
cd adsparkx-support-agent

# 2. Create a virtual environment (recommended)
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) configure an LLM provider
cp .env.example .env
# edit .env and set ONE of ANTHROPIC_API_KEY / OPENAI_API_KEY / OLLAMA_HOST
# then export them, e.g.:
export $(cat .env | xargs)

# 5a. Run the CLI chatbot (required interface)
python app_cli.py

# 5b. Or run the Streamlit web UI (bonus interface)
streamlit run app_streamlit.py

# 6. Run the test suite
python tests/test_agent.py
```

### Environment Variables

| Variable | Required? | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | No | Enables Claude-based generation |
| `ANTHROPIC_MODEL` | No | Defaults to `claude-sonnet-4-6` |
| `OPENAI_API_KEY` | No | Enables GPT-based generation **and** real embedding retrieval |
| `OPENAI_MODEL` / `OPENAI_EMBED_MODEL` | No | Defaults to `gpt-4o-mini` / `text-embedding-3-small` |
| `OLLAMA_HOST` / `OLLAMA_MODEL` | No | Use a local Ollama model instead of a cloud API |

If none are set, the agent runs fully offline in extractive mode.

---

## 8. Bonus: LangGraph Mapping

The current orchestrator (`SupportSession.handle_message`) is a plain Python
state machine rather than a LangGraph graph, chosen so the project has zero
hard dependency on a framework that might not be installable in every
grading environment. It maps directly onto a LangGraph graph if desired:

- **Nodes:** `detect_persona` → `retrieve` → `generate_response` →
  `check_escalation` → (`return_reply` | `build_handoff`)
- **Edge:** a single conditional edge out of `check_escalation`, branching
  on `decision.escalate`.
- **State:** the `TurnResult`/session fields (`turns`, `frustrated_turn_count`,
  `all_retrieved_chunks`) are exactly the shared graph state a LangGraph
  `StateGraph` would thread between nodes.

---

## 9. Example Queries

1. *"Can you explain the API authentication failure and provide error details?"*
   → **Technical Expert**, detailed root-cause + step-by-step from
   `07_api_authentication.md`.
2. *"I've tried everything and nothing works! This is so frustrating!!!"*
   → **Frustrated User**, empathetic opening + simple steps; escalates if
   it's the 2nd+ frustrated turn in the session.
3. *"How does this issue impact operations and when will it be resolved?"*
   → **Business Executive**, concise impact-first summary.
4. *"I want a refund, my card was double charged."*
   → Escalates immediately (`sensitive_topic`) regardless of persona.
5. *"Can I talk to a real person please?"*
   → Escalates immediately (`explicit_human_request`).

---

## 10. Known Limitations & Future Improvements

- **TF-IDF retrieval** is lexical, not semantic — it can miss a relevant
  chunk that's phrased very differently from the query. Swapping in real
  embeddings (already wired for OpenAI; same pattern works for Gemini/BGE)
  closes this gap and is the single highest-impact upgrade.
- **Extractive fallback responses** are functional but less fluent than a
  true LLM-written answer; this only matters when no API key is configured.
- **Persona detection** uses a single message at a time; it does not yet
  build a running persona estimate across a whole conversation (e.g., a
  Technical Expert who becomes a Frustrated User mid-conversation is
  handled correctly per-turn, but the system doesn't yet model "who is this
  person overall").
- **No persistent storage** — conversation history lives only in memory for
  the current process/session; a production version would persist
  conversations and handoff summaries (e.g., SQLite/Postgres) for a real
  support team to pick up.
- **Confidence thresholds** were tuned by hand on this sample knowledge
  base; a production deployment should calibrate them against a labeled
  validation set of real support tickets.
