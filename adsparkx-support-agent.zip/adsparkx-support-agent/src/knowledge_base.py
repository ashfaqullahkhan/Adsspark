"""
knowledge_base.py
------------------
Loads support documents (.md, .txt, .pdf, .docx) from a directory, splits
them into retrieval-sized chunks, and attaches metadata (source document,
section/heading, chunk id) to every chunk.

Chunking strategy
------------------
For Markdown/TXT we chunk by heading ("## Section") first, then further
split any section that exceeds `max_chunk_chars` using a sliding window with
overlap, so a single retrieved chunk is never so big that it dilutes
relevance, and never so small that it loses context. PDFs are chunked per
page first, then the same size-based splitter is applied within a page.
This keeps the metadata (source + page/section) accurate and meaningful,
which is required for citing "documents_used" in the escalation handoff.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import List, Tuple

try:
    from pypdf import PdfReader
except ImportError:  # pragma: no cover
    PdfReader = None


@dataclass
class Chunk:
    chunk_id: str
    text: str
    source: str
    section: str
    extra: dict = field(default_factory=dict)


def _split_by_heading(text: str) -> List[Tuple[str, str]]:
    """Split markdown text into (heading, body) tuples using ## headings.
    The document's H1 title (#) becomes the section name for the intro
    paragraph before the first H2."""
    lines = text.splitlines()
    sections: List[Tuple[str, str]] = []
    current_heading = "Introduction"
    buffer: List[str] = []

    for line in lines:
        h1 = re.match(r"^#\s+(.*)", line)
        h2 = re.match(r"^##\s+(.*)", line)
        if h1:
            current_heading = h1.group(1).strip()
            continue
        if h2:
            if buffer:
                sections.append((current_heading, "\n".join(buffer).strip()))
                buffer = []
            current_heading = h2.group(1).strip()
            continue
        buffer.append(line)

    if buffer:
        sections.append((current_heading, "\n".join(buffer).strip()))

    return [(h, b) for h, b in sections if b.strip()]


def _sliding_window(text: str, max_chars: int, overlap: int) -> List[str]:
    if len(text) <= max_chars:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


def _chunk_raw_text(text: str, source: str, max_chunk_chars: int, overlap: int) -> List[Chunk]:
    chunks: List[Chunk] = []
    sections = _split_by_heading(text) or [("Full Document", text)]
    idx = 0
    for heading, body in sections:
        for piece in _sliding_window(body, max_chunk_chars, overlap):
            idx += 1
            chunks.append(Chunk(chunk_id=f"{source}::{idx}", text=piece.strip(), source=source, section=heading))
    return chunks


def load_markdown_or_text(path: str, max_chunk_chars: int = 900, overlap: int = 120) -> List[Chunk]:
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()
    source = os.path.basename(path)
    return _chunk_raw_text(raw, source, max_chunk_chars, overlap)


def load_pdf(path: str, max_chunk_chars: int = 900, overlap: int = 120) -> List[Chunk]:
    if PdfReader is None:
        raise RuntimeError("pypdf is required to load PDF documents. pip install pypdf")

    source = os.path.basename(path)
    reader = PdfReader(path)
    chunks: List[Chunk] = []
    idx = 0
    for page_num, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if not text:
            continue
        pieces = _sliding_window(text, max_chunk_chars, overlap)
        for piece in pieces:
            idx += 1
            chunks.append(
                Chunk(
                    chunk_id=f"{source}::p{page_num}::{idx}",
                    text=piece.strip(),
                    source=source,
                    section=f"Page {page_num}",
                )
            )
    return chunks


def load_docx(path: str, max_chunk_chars: int = 900, overlap: int = 120) -> List[Chunk]:
    try:
        import docx  # python-docx
    except ImportError as e:
        raise RuntimeError("python-docx is required to load .docx documents.") from e

    source = os.path.basename(path)
    document = docx.Document(path)
    full_text = "\n".join(p.text for p in document.paragraphs)
    return _chunk_raw_text(full_text, source, max_chunk_chars, overlap)


def load_knowledge_base(data_dir: str, max_chunk_chars: int = 900, overlap: int = 120) -> List[Chunk]:
    """Load every supported document under data_dir and return all chunks."""
    all_chunks: List[Chunk] = []
    if not os.path.isdir(data_dir):
        raise FileNotFoundError(f"Knowledge base directory not found: {data_dir}")

    for fname in sorted(os.listdir(data_dir)):
        path = os.path.join(data_dir, fname)
        if not os.path.isfile(path):
            continue
        lower = fname.lower()
        try:
            if lower.endswith(".md") or lower.endswith(".txt"):
                all_chunks.extend(load_markdown_or_text(path, max_chunk_chars, overlap))
            elif lower.endswith(".pdf"):
                all_chunks.extend(load_pdf(path, max_chunk_chars, overlap))
            elif lower.endswith(".docx"):
                all_chunks.extend(load_docx(path, max_chunk_chars, overlap))
        except Exception as e:
            print(f"[knowledge_base] WARNING: failed to load {fname}: {e}")

    return all_chunks
