"""
llm_client.py
-------------
Thin wrapper around whichever LLM provider is configured via environment
variables. Supports:

  - Anthropic Claude  (ANTHROPIC_API_KEY)
  - OpenAI            (OPENAI_API_KEY)
  - Ollama (local)    (OLLAMA_HOST, default http://localhost:11434)

If none are configured, `is_configured()` returns False and the rest of the
pipeline automatically uses the deterministic, extractive (non-hallucinating)
template-based response generator in response_generator.py instead. This
means the project runs fully end-to-end with zero API keys, while still
being "real-LLM ready" -- just set an API key and restart.

Only plain HTTP calls (via `requests`) are used so the project has no hard
dependency on any provider SDK.
"""
from __future__ import annotations

import os
from typing import List, Optional

import requests


class LLMClient:
    def __init__(self):
        self.anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
        self.openai_key = os.environ.get("OPENAI_API_KEY")
        self.ollama_host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
        self.ollama_model = os.environ.get("OLLAMA_MODEL", "llama3")
        self.provider = self._select_provider()

    def _select_provider(self) -> Optional[str]:
        if self.anthropic_key:
            return "anthropic"
        if self.openai_key:
            return "openai"
        if self._ollama_reachable():
            return "ollama"
        return None

    def _ollama_reachable(self) -> bool:
        try:
            requests.get(self.ollama_host, timeout=0.5)
            return True
        except Exception:
            return False

    def is_configured(self) -> bool:
        return self.provider is not None

    def supports_embeddings(self) -> bool:
        # Only OpenAI is wired for embeddings in this reference implementation.
        # (Anthropic does not offer a public embeddings endpoint; Ollama
        # embeddings could be added the same way if a local model is pulled.)
        return self.provider == "openai"

    # ------------------------------------------------------------------ #
    # Text generation
    # ------------------------------------------------------------------ #
    def complete(self, prompt: str, system: str = "", max_tokens: int = 500) -> str:
        if self.provider == "anthropic":
            return self._complete_anthropic(prompt, system, max_tokens)
        if self.provider == "openai":
            return self._complete_openai(prompt, system, max_tokens)
        if self.provider == "ollama":
            return self._complete_ollama(prompt, system, max_tokens)
        raise RuntimeError("No LLM provider configured.")

    def _complete_anthropic(self, prompt, system, max_tokens) -> str:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": self.anthropic_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
                "max_tokens": max_tokens,
                "system": system or "You are a helpful, accurate customer support assistant.",
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")

    def _complete_openai(self, prompt, system, max_tokens) -> str:
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.openai_key}", "Content-Type": "application/json"},
            json={
                "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
                "max_tokens": max_tokens,
                "messages": [
                    {"role": "system", "content": system or "You are a helpful, accurate customer support assistant."},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def _complete_ollama(self, prompt, system, max_tokens) -> str:
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        resp = requests.post(
            f"{self.ollama_host}/api/generate",
            json={"model": self.ollama_model, "prompt": full_prompt, "stream": False},
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json().get("response", "")

    # ------------------------------------------------------------------ #
    # Embeddings (OpenAI only in this reference implementation)
    # ------------------------------------------------------------------ #
    def embed(self, text: str) -> List[float]:
        if self.provider != "openai":
            raise RuntimeError("Embeddings are only wired for the OpenAI provider in this build.")
        resp = requests.post(
            "https://api.openai.com/v1/embeddings",
            headers={"Authorization": f"Bearer {self.openai_key}", "Content-Type": "application/json"},
            json={"model": os.environ.get("OPENAI_EMBED_MODEL", "text-embedding-3-small"), "input": text},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["data"][0]["embedding"]
