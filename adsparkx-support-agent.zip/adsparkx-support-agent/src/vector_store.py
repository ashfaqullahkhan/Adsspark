"""
vector_store.py
----------------
A small vector-store abstraction used by the RAG pipeline.

Why TF-IDF by default?
-----------------------
This project is designed to run completely offline with zero setup and zero
API keys (see README "Zero-Config Mode"). Downloading a sentence-transformer
model or running ChromaDB/FAISS/Pinecone all assume either internet access
(to pull model weights) or extra native dependencies that may not be present
in every grading environment. scikit-learn's TfidfVectorizer + cosine
similarity ships with plain numpy/scipy, needs no network access, and is a
legitimate, explainable "vector database" for a document set of this size
(a few hundred chunks).

The class below exposes the exact interface (`add`, `query`) that a real
vector DB would, so swapping in Chroma/FAISS/Pinecone or real embeddings
(OpenAI/Gemini/BGE) is a drop-in replacement -- see `EmbeddingVectorStore`
for the optional embedding-API-backed implementation, used automatically
when an API key is configured.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src.knowledge_base import Chunk


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


class TfidfVectorStore:
    """Local, dependency-light vector store using TF-IDF + cosine similarity."""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=20000,
            sublinear_tf=True,
        )
        self.chunks: List[Chunk] = []
        self.matrix = None  # sparse TF-IDF matrix, one row per chunk

    def add(self, chunks: List[Chunk]) -> None:
        self.chunks = list(chunks)
        texts = [c.text for c in self.chunks]
        if not texts:
            raise ValueError("No chunks to index. Did the knowledge base load correctly?")
        self.matrix = self.vectorizer.fit_transform(texts)

    def query(self, query_text: str, top_k: int = 4) -> List[RetrievedChunk]:
        if self.matrix is None or not self.chunks:
            return []
        query_vec = self.vectorizer.transform([query_text])
        sims = cosine_similarity(query_vec, self.matrix).flatten()
        top_idx = np.argsort(sims)[::-1][:top_k]
        results = [
            RetrievedChunk(chunk=self.chunks[i], score=float(sims[i]))
            for i in top_idx
            if sims[i] > 0.0
        ]
        return results

    def size(self) -> int:
        return len(self.chunks)


class EmbeddingVectorStore:
    """
    Optional embedding-API-backed vector store (OpenAI / Gemini embeddings).
    Used automatically by build_vector_store() when an embeddings API key is
    present in the environment. Falls back to TfidfVectorStore otherwise.
    Embeddings are cached in-memory as a numpy matrix; cosine similarity is
    used for retrieval, exactly like a real vector DB would do under the hood.
    """

    def __init__(self, llm_client):
        self.llm_client = llm_client
        self.chunks: List[Chunk] = []
        self.matrix: Optional[np.ndarray] = None

    def add(self, chunks: List[Chunk]) -> None:
        self.chunks = list(chunks)
        vectors = [self.llm_client.embed(c.text) for c in self.chunks]
        self.matrix = np.array(vectors)

    def query(self, query_text: str, top_k: int = 4) -> List[RetrievedChunk]:
        if self.matrix is None or not self.chunks:
            return []
        qvec = np.array(self.llm_client.embed(query_text)).reshape(1, -1)
        sims = cosine_similarity(qvec, self.matrix).flatten()
        top_idx = np.argsort(sims)[::-1][:top_k]
        return [
            RetrievedChunk(chunk=self.chunks[i], score=float(sims[i]))
            for i in top_idx
            if sims[i] > 0.0
        ]

    def size(self) -> int:
        return len(self.chunks)


def build_vector_store(chunks: List[Chunk], llm_client=None):
    """
    Factory: choose an embedding-backed store if an embeddings-capable LLM
    client is configured, otherwise fall back to the local TF-IDF store.
    """
    if llm_client is not None and llm_client.supports_embeddings():
        try:
            store = EmbeddingVectorStore(llm_client)
            store.add(chunks)
            return store
        except Exception as e:
            print(f"[vector_store] Embedding backend failed ({e}); falling back to TF-IDF.")

    store = TfidfVectorStore()
    store.add(chunks)
    return store
