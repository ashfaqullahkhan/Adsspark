"""
handoff.py
----------
Builds the structured human-handoff summary produced when a conversation is
escalated, matching the schema required by the assignment:

{
  "persona": ...,
  "issue": ...,
  "documents_used": [...],
  "attempted_steps": [...],
  "recommendation": ...
}

We extend it slightly with `conversation_history`, `escalation_reasons`, and
`timestamp` since the spec also asks for conversation history and recommended
next steps to be present -- these are additive and don't break the required
schema.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from src.vector_store import RetrievedChunk


@dataclass
class Turn:
    role: str  # "user" or "agent"
    text: str
    persona: Optional[str] = None


def _summarize_issue(turns: List[Turn]) -> str:
    user_turns = [t.text for t in turns if t.role == "user"]
    if not user_turns:
        return "No issue description captured."
    # Use the first user message as the primary issue statement; keep it short.
    issue = user_turns[0].strip()
    return issue if len(issue) <= 200 else issue[:197] + "..."


def _recommend_next_step(escalation_reasons: List[str], persona: str) -> str:
    reasons_text = " ".join(escalation_reasons).lower()
    if "sensitive_topic" in reasons_text:
        return "Route to billing/security specialist; verify identity before taking account or payment action."
    if "no_relevant_docs" in reasons_text or "retrieval_confidence_low" in reasons_text:
        return "Knowledge base did not have a confident answer; investigate directly and consider adding a KB article once resolved."
    if "repeated_dissatisfaction" in reasons_text:
        return "Customer has been unsatisfied across multiple turns; prioritize a direct human follow-up call rather than further chat replies."
    if "explicit_human_request" in reasons_text:
        return "Customer explicitly requested a human; connect promptly."
    return "Review conversation and continue troubleshooting with the customer."


def build_handoff_summary(
    turns: List[Turn],
    persona: str,
    documents_used: List[RetrievedChunk],
    escalation_reasons: List[str],
) -> Dict:
    attempted_steps = [t.text for t in turns if t.role == "agent"]
    doc_names = sorted({rc.chunk.source for rc in documents_used}) if documents_used else []

    summary = {
        "persona": persona,
        "issue": _summarize_issue(turns),
        "documents_used": doc_names,
        "attempted_steps": attempted_steps,
        "recommendation": _recommend_next_step(escalation_reasons, persona),
        "escalation_reasons": escalation_reasons,
        "conversation_history": [
            {"role": t.role, "text": t.text, **({"persona": t.persona} if t.persona else {})}
            for t in turns
        ],
        "timestamp": _dt.datetime.utcnow().isoformat() + "Z",
    }
    return summary
