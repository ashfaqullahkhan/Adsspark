"""
response_generator.py
----------------------
Turns retrieved knowledge-base chunks into a persona-adapted response.

Two modes:
  1. LLM mode (if llm_client.is_configured()): we build a strict
     "answer ONLY from the context below" prompt, styled per persona, and
     call the configured LLM. This is the "real" RAG generation path.
  2. Extractive fallback (no LLM configured): we deterministically compose
     the response directly from the retrieved chunk text using persona-
     specific templates (e.g., numbered steps for Technical Expert,
     reassurance framing for Frustrated User, a one-line business-impact
     summary for Business Executive). This guarantees zero hallucination
     and keeps the whole project runnable offline, while still visibly
     varying tone/format per persona as required by the assignment.

In both modes, the response is grounded ONLY in retrieved chunks -- if no
chunks were retrieved, we never fabricate an answer; escalation.py will
already have flagged this conversation for human handoff.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from src.vector_store import RetrievedChunk

PERSONA_SYSTEM_PROMPTS = {
    "Technical Expert": (
        "You are a senior technical support engineer. The user is technically "
        "fluent. Be detailed and precise: include root-cause explanation, "
        "step-by-step troubleshooting, and relevant technical specifics "
        "(error codes, config names, endpoints) when present in the context. "
        "Do not oversimplify."
    ),
    "Frustrated User": (
        "You are an empathetic customer support agent. The user is frustrated. "
        "Open with a brief, genuine acknowledgement of their frustration, then "
        "give simple, reassuring, action-oriented steps in plain language. "
        "Avoid jargon. Keep paragraphs short."
    ),
    "Business Executive": (
        "You are a support agent speaking to a business executive. Be concise "
        "and impact-focused. Lead with the bottom line (what this means for "
        "their operations and timeline), avoid technical jargon, and include "
        "an estimated resolution guidance if available in the context."
    ),
    "General User": (
        "You are a friendly, clear customer support agent. Use plain "
        "language and a balanced level of detail."
    ),
}


@dataclass
class GeneratedResponse:
    text: str
    mode: str  # "llm" or "extractive"
    grounded: bool


def _build_context_block(chunks: List[RetrievedChunk]) -> str:
    parts = []
    for i, rc in enumerate(chunks, start=1):
        parts.append(
            f"[Source {i}: {rc.chunk.source} | {rc.chunk.section} | relevance={rc.score:.2f}]\n{rc.chunk.text}"
        )
    return "\n\n".join(parts)


def _llm_generate(persona: str, user_message: str, chunks: List[RetrievedChunk], llm_client) -> str:
    context = _build_context_block(chunks)
    system = PERSONA_SYSTEM_PROMPTS.get(persona, PERSONA_SYSTEM_PROMPTS["General User"])
    prompt = (
        "Answer the customer's message using ONLY the context below. "
        "If the context does not fully answer the question, say what you can "
        "based on the context and note that a human agent will follow up on "
        "the rest. Never invent information that is not in the context.\n\n"
        f"CONTEXT:\n{context}\n\n"
        f"CUSTOMER MESSAGE:\n{user_message}\n\n"
        "RESPONSE:"
    )
    return llm_client.complete(prompt, system=system, max_tokens=500).strip()


def _extractive_generate(persona: str, user_message: str, chunks: List[RetrievedChunk]) -> str:
    """Deterministic, template-based, zero-hallucination fallback."""
    if not chunks:
        return (
            "I couldn't find anything in our knowledge base that directly answers this. "
            "I'm escalating this to a human support agent who can help further."
        )

    best = chunks[0]
    # Pull out a few sentences from the best chunk(s) rather than dumping
    # the whole chunk, so the answer stays readable.
    sentences: List[str] = []
    for rc in chunks[:2]:
        for s in rc.chunk.text.replace("\n", " ").split(". "):
            s = s.strip().rstrip(".")
            if s and len(s) > 15:
                sentences.append(s)
    sentences = sentences[:5]

    sources_line = ", ".join(sorted({f"{rc.chunk.source} ({rc.chunk.section})" for rc in chunks}))

    if persona == "Technical Expert":
        steps = "\n".join(f"{i+1}. {s}." for i, s in enumerate(sentences))
        return (
            f"Here's the relevant detail from our documentation:\n\n{steps}\n\n"
            f"Source(s): {sources_line}\n"
            "Let me know if you need the raw API/log details and I can dig further."
        )

    if persona == "Frustrated User":
        lead = sentences[0] + "." if sentences else ""
        rest = " ".join(f"{s}." for s in sentences[1:3])
        return (
            "I'm sorry this has been frustrating — let's get it sorted.\n\n"
            f"{lead} {rest}\n\n"
            "If this doesn't fully fix it, I'll make sure a human agent follows up with you directly."
        )

    if persona == "Business Executive":
        summary = sentences[0] + "." if sentences else ""
        return (
            f"Bottom line: {summary}\n\n"
            f"Reference: {best.chunk.source} ({best.chunk.section}). "
            "Happy to provide a more detailed technical breakdown if useful, "
            "or connect you with our account team for SLA-specific commitments."
        )

    # General User
    body = " ".join(f"{s}." for s in sentences)
    return f"{body}\n\nSource(s): {sources_line}"


def generate_response(
    persona: str,
    user_message: str,
    chunks: List[RetrievedChunk],
    llm_client=None,
) -> GeneratedResponse:
    if llm_client is not None and llm_client.is_configured() and chunks:
        try:
            text = _llm_generate(persona, user_message, chunks, llm_client)
            return GeneratedResponse(text=text, mode="llm", grounded=True)
        except Exception as e:
            print(f"[response_generator] LLM generation failed ({e}); falling back to extractive mode.")

    text = _extractive_generate(persona, user_message, chunks)
    return GeneratedResponse(text=text, mode="extractive", grounded=bool(chunks))
