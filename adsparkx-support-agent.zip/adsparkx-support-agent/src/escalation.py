"""
escalation.py
--------------
Decides whether a conversation must be escalated to a human agent.

Escalation triggers (all configurable via EscalationConfig):
  1. retrieval_confidence_low -> top retrieved chunk score below threshold
  2. no_relevant_docs         -> retrieval returned zero chunks
  3. sensitive_topic          -> message matches billing/legal/account/security
                                  keyword list (these must always go to a human
                                  regardless of retrieval quality)
  4. repeated_dissatisfaction -> user has sent N+ messages in this session that
                                  were classified as Frustrated User, or the
                                  user explicitly says the previous answer
                                  didn't help
  5. explicit_human_request   -> user explicitly asks for a human

Each trigger is independently togglable and tunable so it can be adapted to a
different domain without touching the agent orchestration code.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List


SENSITIVE_KEYWORDS = [
    "refund", "chargeback", "double billed", "double charge", "unauthorized charge",
    "cancel my subscription", "delete my account", "delete my workspace",
    "transfer ownership", "lawsuit", "legal", "gdpr", "data breach", "compromised",
    "hacked", "unauthorized access", "lost access to 2fa", "lost my 2fa",
    "dispute", "fraud", "sue", "attorney", "lawyer", "compliance audit",
]

HUMAN_REQUEST_PATTERNS = [
    r"\btalk to (a )?human\b", r"\breal person\b", r"\bspeak (to|with) (a )?(agent|person|human)\b",
    r"\bescalate\b", r"\bmanager\b", r"\bsupervisor\b", r"\bhuman support\b",
]


@dataclass
class EscalationConfig:
    confidence_threshold: float = 0.12          # below this top retrieval score => escalate
    frustration_repeat_threshold: int = 2        # N+ Frustrated-User turns in a session => escalate
    enable_sensitive_topic_check: bool = True
    enable_low_confidence_check: bool = True
    enable_repeated_dissatisfaction_check: bool = True
    enable_human_request_check: bool = True


@dataclass
class EscalationDecision:
    escalate: bool
    reasons: List[str] = field(default_factory=list)


def _matches_sensitive_topic(message: str) -> bool:
    text = message.lower()
    return any(kw in text for kw in SENSITIVE_KEYWORDS)


def _matches_human_request(message: str) -> bool:
    text = message.lower()
    return any(re.search(p, text) for p in HUMAN_REQUEST_PATTERNS)


def evaluate_escalation(
    message: str,
    top_retrieval_score: float,
    num_retrieved: int,
    persona: str,
    frustrated_turns_in_session: int,
    config: EscalationConfig = EscalationConfig(),
) -> EscalationDecision:
    reasons: List[str] = []

    if config.enable_human_request_check and _matches_human_request(message):
        reasons.append("explicit_human_request")

    if config.enable_sensitive_topic_check and _matches_sensitive_topic(message):
        reasons.append("sensitive_topic (billing/legal/account/security)")

    if num_retrieved == 0:
        reasons.append("no_relevant_docs_found")
    elif config.enable_low_confidence_check and top_retrieval_score < config.confidence_threshold:
        reasons.append(f"retrieval_confidence_low ({top_retrieval_score:.2f} < {config.confidence_threshold})")

    if (
        config.enable_repeated_dissatisfaction_check
        and persona == "Frustrated User"
        and frustrated_turns_in_session >= config.frustration_repeat_threshold
    ):
        reasons.append(
            f"repeated_dissatisfaction ({frustrated_turns_in_session} frustrated turns in session)"
        )

    return EscalationDecision(escalate=len(reasons) > 0, reasons=reasons)
