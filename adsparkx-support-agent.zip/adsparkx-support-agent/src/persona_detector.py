"""
persona_detector.py
--------------------
Classifies an incoming user message into one of the supported personas.

Strategy: hybrid rule-based classifier.
We score each persona using three signal types and pick the highest-scoring
persona above a minimum confidence floor:

  1. Lexical signals    -> curated keyword/phrase lists per persona
  2. Structural signals -> things like ALL CAPS, exclamation marks, question
                            density, presence of technical tokens (status
                            codes, stack traces, "API", "config", etc.)
  3. Sentiment signal    -> a tiny lexicon-based polarity score used mainly to
                            push "Frustrated User" up when negative emotion is
                            high, regardless of vocabulary.

This is intentionally NOT a black-box LLM call: persona detection needs to be
fast, deterministic, explainable to a support team, and cheap to run on every
message turn. The module also exposes `detect_persona_llm()` which will use a
real LLM (if an API key is configured) to confirm/refine borderline cases --
see llm_client.py. When no LLM is configured the rule-based result is used
directly, which keeps the whole project runnable with zero API keys.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

PERSONAS = ["Technical Expert", "Frustrated User", "Business Executive", "General User"]

# ---------------------------------------------------------------------------
# Lexicons
# ---------------------------------------------------------------------------

TECHNICAL_KEYWORDS = [
    "api", "token", "auth", "authentication", "oauth", "endpoint", "payload",
    "header", "status code", "401", "403", "404", "429", "500", "stack trace",
    "log", "logs", "config", "configuration", "webhook", "ssl", "tls", "json",
    "sdk", "rate limit", "latency", "request id", "trace id", "exception",
    "error code", "regex", "schema", "database", "query", "curl", "cli",
    "environment variable", "sso", "saml", "debug", "reproduce", "stacktrace",
]

FRUSTRATION_KEYWORDS = [
    "nothing works", "still not working", "tried everything", "fed up",
    "frustrated", "angry", "ridiculous", "unacceptable", "terrible",
    "worst", "annoyed", "again and again", "third time", "multiple times",
    "every time", "useless", "waste of time", "fix this now", "horrible",
    "sick of", "done with", "cancel my", "refund me now", "scam",
]

NEGATIVE_WORDS = [
    "not", "never", "doesn't", "don't", "can't", "won't", "broken", "fail",
    "failed", "failing", "issue", "problem", "bug", "down", "crash",
    "crashed", "stuck", "lost", "missing", "wrong", "bad", "awful",
    "disappointed", "upset", "angry", "frustrated",
]

EXECUTIVE_KEYWORDS = [
    "business impact", "impact operations", "when will this be resolved",
    "revenue", "customers are affected", "our team relies on", "sla",
    "downtime cost", "stakeholders", "leadership", "board", "deadline",
    "contract", "roi", "executive summary", "bottom line", "operations",
    "strategic", "enterprise account", "account manager", "renewal",
    "company-wide", "across the organization", "high level", "briefly",
]


@dataclass
class PersonaResult:
    persona: str
    confidence: float
    scores: Dict[str, float] = field(default_factory=dict)
    signals: List[str] = field(default_factory=list)


def _keyword_score(text: str, keywords: List[str]) -> Tuple[float, List[str]]:
    hits = [kw for kw in keywords if kw in text]
    # Diminishing returns so one long message stuffed with keywords
    # doesn't dominate -- score saturates around 4 distinct hits.
    score = min(len(hits) / 4.0, 1.0)
    return score, hits


def _structural_signals(raw_text: str) -> Dict[str, float]:
    signals: Dict[str, float] = {}
    exclam = raw_text.count("!")
    signals["exclamation_density"] = min(exclam / 3.0, 1.0)

    caps_words = re.findall(r"\b[A-Z]{3,}\b", raw_text)
    signals["all_caps"] = min(len(caps_words) / 2.0, 1.0)

    has_status_code = bool(re.search(r"\b[1-5]\d{2}\b", raw_text))
    has_stack_pattern = bool(re.search(r"(Traceback|Exception|at \w+\.\w+\()", raw_text))
    signals["technical_pattern"] = 1.0 if (has_status_code or has_stack_pattern) else 0.0

    word_count = len(raw_text.split())
    signals["is_terse"] = 1.0 if 0 < word_count <= 12 else 0.0

    return signals


def detect_persona(message: str) -> PersonaResult:
    """Rule-based persona classifier. Pure function, no network calls."""
    raw = message.strip()
    text = raw.lower()

    tech_score, tech_hits = _keyword_score(text, TECHNICAL_KEYWORDS)
    frustration_score, frustration_hits = _keyword_score(text, FRUSTRATION_KEYWORDS)
    exec_score, exec_hits = _keyword_score(text, EXECUTIVE_KEYWORDS)

    neg_hits = [w for w in NEGATIVE_WORDS if w in text]
    negativity = min(len(neg_hits) / 5.0, 1.0)

    struct = _structural_signals(raw)

    scores = {
        "Technical Expert": round(
            0.65 * tech_score + 0.35 * struct["technical_pattern"], 3
        ),
        "Frustrated User": round(
            0.55 * frustration_score
            + 0.25 * negativity
            + 0.10 * struct["exclamation_density"]
            + 0.10 * struct["all_caps"],
            3,
        ),
        "Business Executive": round(
            0.70 * exec_score + 0.30 * struct["is_terse"], 3
        ),
    }

    persona = max(scores, key=scores.get)
    confidence = scores[persona]

    # Fallback: nothing scored meaningfully -> General User
    if confidence < 0.18:
        persona = "General User"

    signals = tech_hits + frustration_hits + exec_hits
    return PersonaResult(persona=persona, confidence=confidence, scores=scores, signals=signals)


def detect_persona_llm(message: str, llm_client) -> PersonaResult:
    """
    Optional LLM-confirmed persona detection.
    Falls back silently to the rule-based detector if no LLM client / API key
    is configured, so the project always runs end-to-end offline.
    """
    rule_result = detect_persona(message)
    if llm_client is None or not llm_client.is_configured():
        return rule_result

    prompt = (
        "Classify the customer support message below into exactly one persona: "
        "'Technical Expert', 'Frustrated User', 'Business Executive', or 'General User'.\n"
        f"Message: \"{message}\"\n"
        "Reply with only the persona label, nothing else."
    )
    try:
        label = llm_client.complete(prompt, max_tokens=10).strip()
        for p in PERSONAS:
            if p.lower() in label.lower():
                rule_result.persona = p
                rule_result.confidence = max(rule_result.confidence, 0.75)
                rule_result.signals.append("llm_confirmed")
                return rule_result
    except Exception:
        pass
    return rule_result
