"""
tests/test_agent.py
--------------------
Lightweight sanity tests (no pytest dependency required -- run directly with
`python tests/test_agent.py`). Covers persona detection, retrieval grounding,
and escalation triggers, which are the three graded behaviors of the system.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.escalation import EscalationConfig, evaluate_escalation
from src.knowledge_base import load_knowledge_base
from src.persona_detector import detect_persona
from src.vector_store import build_vector_store

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


def test_persona_detection():
    cases = {
        "Can you explain the API authentication failure and provide error details?": "Technical Expert",
        "I've tried everything and nothing works! This is so frustrating!!!": "Frustrated User",
        "How does this issue impact operations and when will it be resolved?": "Business Executive",
    }
    for message, expected in cases.items():
        result = detect_persona(message)
        assert result.persona == expected, f"Expected {expected}, got {result.persona} for: {message}"
    print("test_persona_detection: PASS")


def test_retrieval_is_grounded():
    chunks = load_knowledge_base(DATA_DIR)
    assert len(chunks) > 0, "Knowledge base failed to load any chunks"
    store = build_vector_store(chunks)
    results = store.query("How do I reset my password?", top_k=3)
    assert len(results) > 0
    assert any("password" in r.chunk.text.lower() for r in results)
    print("test_retrieval_is_grounded: PASS")


def test_escalation_sensitive_topic():
    decision = evaluate_escalation(
        message="I want a refund, my card was double charged",
        top_retrieval_score=0.9,
        num_retrieved=3,
        persona="Frustrated User",
        frustrated_turns_in_session=1,
        config=EscalationConfig(),
    )
    assert decision.escalate is True
    assert any("sensitive_topic" in r for r in decision.reasons)
    print("test_escalation_sensitive_topic: PASS")


def test_escalation_low_confidence():
    decision = evaluate_escalation(
        message="random unrelated question about nothing in particular",
        top_retrieval_score=0.01,
        num_retrieved=1,
        persona="General User",
        frustrated_turns_in_session=0,
        config=EscalationConfig(confidence_threshold=0.12),
    )
    assert decision.escalate is True
    print("test_escalation_low_confidence: PASS")


def test_no_escalation_for_confident_answer():
    decision = evaluate_escalation(
        message="How do I create a project board?",
        top_retrieval_score=0.5,
        num_retrieved=3,
        persona="General User",
        frustrated_turns_in_session=0,
        config=EscalationConfig(),
    )
    assert decision.escalate is False
    print("test_no_escalation_for_confident_answer: PASS")


if __name__ == "__main__":
    test_persona_detection()
    test_retrieval_is_grounded()
    test_escalation_sensitive_topic()
    test_escalation_low_confidence()
    test_no_escalation_for_confident_answer()
    print("\nAll tests passed.")
