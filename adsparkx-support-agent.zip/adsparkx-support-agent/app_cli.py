#!/usr/bin/env python3
"""
app_cli.py
----------
Interactive command-line chatbot for the Persona-Adaptive Customer Support
Agent. This satisfies the assignment's minimum UI requirement and displays,
for every turn:
  - The user message
  - Detected persona (+ confidence)
  - Retrieved sources
  - Generated response
  - Escalation status

Run:
    python app_cli.py
    python app_cli.py --data-dir data --top-k 4
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.escalation import EscalationConfig
from src.knowledge_base import load_knowledge_base
from src.llm_client import LLMClient
from src.vector_store import build_vector_store
from src.agent import SupportSession

DIVIDER = "-" * 70


def banner(llm_client: LLMClient, kb_size: int, num_chunks: int):
    print("=" * 70)
    print(" CloudDesk Persona-Adaptive Support Agent (CLI)")
    print("=" * 70)
    mode = llm_client.provider if llm_client.is_configured() else "extractive (no LLM key configured)"
    print(f"  Generation mode : {mode}")
    print(f"  Knowledge base  : {kb_size} documents -> {num_chunks} chunks indexed")
    print(f"  Vector backend  : {'embedding API' if llm_client.supports_embeddings() else 'TF-IDF (local)'}")
    print(DIVIDER)
    print("Type a message as a customer would. Type 'exit' or 'quit' to stop.")
    print("Try: \"Can you explain the API authentication failure and provide error details?\"")
    print(DIVIDER)


def print_turn_result(result):
    print(f"\n[Detected Persona] {result.persona}  (confidence={result.persona_confidence:.2f})")

    if result.retrieved:
        print("[Retrieved Sources]")
        for rc in result.retrieved:
            print(f"   - {rc.chunk.source} | {rc.chunk.section} | score={rc.score:.3f}")
    else:
        print("[Retrieved Sources] none")

    print(f"[Generation Mode] {result.response_mode}")
    print(f"\nAgent: {result.response_text}")

    if result.escalated:
        print("\n*** ESCALATED TO HUMAN SUPPORT ***")
        print(f"Reasons: {', '.join(result.escalation_reasons)}")
        print("Handoff Summary:")
        print(json.dumps(result.handoff_summary, indent=2))
    print(DIVIDER)


def main():
    parser = argparse.ArgumentParser(description="Persona-Adaptive Customer Support Agent (CLI)")
    parser.add_argument("--data-dir", default=os.path.join(os.path.dirname(__file__), "data"))
    parser.add_argument("--top-k", type=int, default=4)
    parser.add_argument("--confidence-threshold", type=float, default=0.12,
                         help="Retrieval score below which we escalate due to low confidence.")
    args = parser.parse_args()

    llm_client = LLMClient()

    print("Loading knowledge base...")
    chunks = load_knowledge_base(args.data_dir)
    num_docs = len({c.source for c in chunks})
    vector_store = build_vector_store(chunks, llm_client=llm_client)

    banner(llm_client, num_docs, vector_store.size())

    session = SupportSession(
        vector_store=vector_store,
        llm_client=llm_client,
        escalation_config=EscalationConfig(confidence_threshold=args.confidence_threshold),
        top_k=args.top_k,
    )

    while True:
        try:
            message = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not message:
            continue
        if message.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        result = session.handle_message(message)
        print_turn_result(result)


if __name__ == "__main__":
    main()
