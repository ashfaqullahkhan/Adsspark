"""
app_streamlit.py
-----------------
Bonus chat-style web UI for the Persona-Adaptive Customer Support Agent.

Run:
    pip install streamlit
    streamlit run app_streamlit.py
"""
import json
import os
import sys

import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.escalation import EscalationConfig
from src.knowledge_base import load_knowledge_base
from src.llm_client import LLMClient
from src.vector_store import build_vector_store
from src.agent import SupportSession

st.set_page_config(page_title="CloudDesk Support Agent", page_icon="💬", layout="wide")


@st.cache_resource(show_spinner="Loading knowledge base and building the vector index...")
def init_session():
    data_dir = os.path.join(os.path.dirname(__file__), "data")
    llm_client = LLMClient()
    chunks = load_knowledge_base(data_dir)
    vector_store = build_vector_store(chunks, llm_client=llm_client)
    return llm_client, vector_store, len({c.source for c in chunks})


llm_client, vector_store, num_docs = init_session()

if "session" not in st.session_state:
    st.session_state.session = SupportSession(
        vector_store=vector_store,
        llm_client=llm_client,
        escalation_config=EscalationConfig(),
    )
if "history" not in st.session_state:
    st.session_state.history = []

with st.sidebar:
    st.header("System Status")
    mode = llm_client.provider if llm_client.is_configured() else "Extractive (no LLM key set)"
    st.metric("Generation mode", mode)
    st.metric("Knowledge base docs", num_docs)
    st.metric("Indexed chunks", vector_store.size())
    st.caption(
        "Set ANTHROPIC_API_KEY, OPENAI_API_KEY, or run Ollama locally to "
        "switch from extractive to full LLM generation. See .env.example."
    )
    if st.button("Reset conversation"):
        st.session_state.session = SupportSession(
            vector_store=vector_store, llm_client=llm_client, escalation_config=EscalationConfig()
        )
        st.session_state.history = []
        st.rerun()

st.title("💬 CloudDesk Persona-Adaptive Support Agent")
st.caption("Detects your persona, retrieves grounded answers from the knowledge base, and escalates when needed.")

for turn in st.session_state.history:
    with st.chat_message("user"):
        st.write(turn["user_message"])
    with st.chat_message("assistant"):
        st.markdown(f"**Persona detected:** {turn['persona']} (confidence {turn['persona_confidence']:.2f})")
        if turn["retrieved"]:
            with st.expander("Retrieved sources"):
                for r in turn["retrieved"]:
                    st.write(f"- `{r['source']}` — {r['section']} (score {r['score']:.3f})")
        st.write(turn["response_text"])
        if turn["escalated"]:
            st.error(f"Escalated to human support — reasons: {', '.join(turn['escalation_reasons'])}")
            with st.expander("Human handoff summary (JSON)"):
                st.code(json.dumps(turn["handoff_summary"], indent=2), language="json")

prompt = st.chat_input("Type your support question...")
if prompt:
    result = st.session_state.session.handle_message(prompt)
    st.session_state.history.append(
        {
            "user_message": prompt,
            "persona": result.persona,
            "persona_confidence": result.persona_confidence,
            "retrieved": [
                {"source": r.chunk.source, "section": r.chunk.section, "score": r.score} for r in result.retrieved
            ],
            "response_text": result.response_text,
            "escalated": result.escalated,
            "escalation_reasons": result.escalation_reasons,
            "handoff_summary": result.handoff_summary,
        }
    )
    st.rerun()
